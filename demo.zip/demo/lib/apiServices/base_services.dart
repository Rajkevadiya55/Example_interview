class ApiRoutes{

  static String baseUrl = 'https://fansclub.9dottechno.com/api';

  static String login = '$baseUrl/login';
  static String favouritePlayer = '$baseUrl/favoriteplayerlist';
  static String getUserTotalLike = '$baseUrl/getusertotallike';

}